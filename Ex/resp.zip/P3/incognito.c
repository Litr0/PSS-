int *fun(int*a,int x){
    
}